# HiDisk AppOps (KernelSU companion)

This is a tiny KernelSU `.su` module that keeps one device-level prerequisite
in place for the HiDisk Hook LSPosed module:

```text
appops set com.huawei.hidisk MANAGE_EXTERNAL_STORAGE allow
```

## Why

- Gallery (`com.hihonor.photos`) writes cloud-album cache files under
  `/storage/emulated/0/.photoShare/thumb/...`; those files are owned by
  MediaProvider (`u0_a178`, group `media_rw`, mode 660).
- `com.huawei.hidisk` (uid 10054) cannot open them directly without
  `MANAGE_EXTERNAL_STORAGE`. Upload then fails with `ret=1011`; cloud
  thumbnail downloads can fail with EPERM/4005 as well.
- The HiDisk Hook APK handles the trust/login/UI/upload-path logic, but an
  LSPosed module cannot grant an AppOp to another package. This companion does
  it at boot.

## Install

Copy this directory to `/data/adb/modules/hidisk_appops` (or flash the zip),
then either reboot or run:

```sh
su -c 'sh /data/adb/modules/hidisk_appops/service.sh'
```

Verify:

```sh
adb shell appops get com.huawei.hidisk MANAGE_EXTERNAL_STORAGE
# MANAGE_EXTERNAL_STORAGE: allow
```

## Scope

This module only sets one AppOp. It does not modify the Gallery database,
system partitions, or the HiDisk APK.
